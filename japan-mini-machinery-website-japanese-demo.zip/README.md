# Japan Mini Machinery Website — Preview

## What is included

### Current preview language
The public-facing site has been converted to Japanese, with Japanese-oriented typography and labels. The code remains easy to edit if the client wants different Japanese wording.

- Responsive public home page
- Responsive machine catalogue
- Individual machine pages with permanent shareable URLs
- YouTube embed from a pasted URL
- Highlighted machine specifications
- Price or "Contact for Price"
- LINE contact button + QR code
- Mobile-friendly admin panel
- Two admin logins
- Machine image uploads
- Draft / Published / Sold status
- Reusable/suggested specification names
- English content prepared for easy Japanese translation
- Sample Kubota KH-012 listing using the supplied reference image and YouTube video

## Run locally

1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run:
   npm install
   npm start
4. Open:
   http://localhost:3000
5. Admin:
   http://localhost:3000/admin.html

Preview admin accounts:
- admin1@example.jp / Preview123!
- admin2@example.jp / Preview456!

## IMPORTANT BEFORE REAL LAUNCH

The included login defaults are for preview only. On hosting, set:
- ADMIN1_EMAIL
- ADMIN1_PASSWORD
- ADMIN2_EMAIL
- ADMIN2_PASSWORD
- SESSION_SECRET

Also enable HTTPS and set the session cookie to secure:true in server.js for production.

The sample LINE link and QR code are placeholders. Replace them with the company's real LINE URL/QR.

## Publishing

A simple option is a Node.js host such as Render, Railway, Fly.io, or a VPS that supports Node.js.

Upload this whole project, run `npm install`, and start it with:
npm start

Point the chosen .jp domain's DNS to the hosting provider. Exact DNS records depend on the host.

### Important storage note
This preview stores product data in data/products.json and uploaded images in public/uploads. For a serious production deployment with multiple administrators, use persistent disk/storage or a database + object storage. Do not rely on an ephemeral filesystem host.

## How to translate to Japanese

The visible text is intentionally straightforward to edit.

Search these files for English:
- public/index.html
- public/products.html
- public/product.html
- public/admin.html
- public/app.js
- public/admin.js

Replace phrases such as:
- Home → ホーム
- Machines → 機械
- About → 会社情報
- Contact → お問い合わせ
- View machines → 機械を見る
- Contact for Price → 価格はお問い合わせください
- Specifications → 仕様
- Machine video → 機械動画
- Interested in this machine? → この機械にご興味がありますか？

For a final Japanese launch, use Japanese-native copy rather than literal machine translation.

## Adding the real LINE QR

Replace:
public/assets/line-qr.png

with the company's real QR image, keeping the same filename.

Change the LINE destination in:
public/index.html
public/app.js
and any other place containing:
https://line.me/R/ti/p/@sample-machinery

## Product workflow

Admin → Add machine → Upload photos → title/category → description → YouTube URL → specifications → price/contact option → status → Save.

Each machine automatically receives an ID and can be shared at:
 /product.html?id=YOUR-MACHINE-ID

For a more polished final deployment, a reverse-proxy rewrite can make this:
 /products/your-machine-name



## Free preview hosting

### Option A — Cloudflare Pages (recommended for a static visual demo)
Cloudflare Pages can deploy static HTML/CSS/JS and gives you a free `*.pages.dev` address. Upload the public-facing files (or connect the project to GitHub). This is excellent for showing the owner the visual design on phone and desktop.

Important: the current admin panel uses a Node.js server API, so **the admin panel will not work on GitHub Pages or a basic static Pages deployment**. For the full admin system, deploy the Node.js backend to a server/Node-compatible host or convert the backend to serverless/database services.

### Option B — Local demo
Run `npm install` and `npm start`, then open `http://localhost:3000`.

### Final production
For the real `.jp` website, use a proper full-stack host with persistent database/storage, HTTPS, secure environment variables and a real domain.
