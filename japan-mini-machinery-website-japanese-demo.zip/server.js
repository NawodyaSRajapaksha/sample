const express = require("express");
const session = require("express-session");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "public", "uploads");
const DATA_FILE = path.join(DATA_DIR, "products.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

if (!fs.existsSync(DATA_FILE)) {
  const seed = [{
    id: "kubota-kh-012",
    title: "Kubota KH-012 Mini Excavator",
    category: "Mini Excavator",
    description: "A compact Kubota mini excavator in the 1-ton class. This preview listing demonstrates how a machine can be presented with clear specifications, photos and an embedded YouTube walk-around.",
    videoUrl: "https://youtu.be/JqDzWHW0vWM",
    priceMode: "contact",
    price: "",
    status: "published",
    images: ["/assets/kubota-kh012.jpg"],
    specs: [
      { key: "Manufacturer", value: "Kubota" },
      { key: "Model", value: "KH-012" },
      { key: "Class", value: "1-ton class" },
      { key: "Machine Type", value: "Mini excavator" },
      { key: "Fuel", value: "Diesel" }
    ],
    createdAt: new Date().toISOString()
  }];
  fs.writeFileSync(DATA_FILE, JSON.stringify(seed, null, 2));
}

function loadProducts() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function saveProducts(products) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2));
}

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-production",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false }
}));
app.use(express.static(path.join(ROOT, "public")));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_, __, cb) => cb(null, UPLOAD_DIR),
    filename: (_, file, cb) => {
      const safe = file.originalname.toLowerCase().replace(/[^a-z0-9.]+/g, "-");
      cb(null, Date.now() + "-" + safe);
    }
  }),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    cb(null, /^image\/(jpeg|png|webp|jpg)$/.test(file.mimetype));
  }
});

const admins = [
  { email: process.env.ADMIN1_EMAIL || "admin1@example.jp", password: process.env.ADMIN1_PASSWORD || "Preview123!" },
  { email: process.env.ADMIN2_EMAIL || "admin2@example.jp", password: process.env.ADMIN2_PASSWORD || "Preview456!" }
];

function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.status(401).json({ error: "Unauthorized" });
  next();
}

app.get("/api/products", (req, res) => {
  const products = loadProducts();
  res.json(products.filter(p => p.status === "published"));
});

app.get("/api/products/:id", (req, res) => {
  const product = loadProducts().find(p => p.id === req.params.id);
  if (!product || product.status !== "published") return res.status(404).json({ error: "Product not found" });
  res.json(product);
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body || {};
  const admin = admins.find(a => a.email.toLowerCase() === String(email || "").toLowerCase() && a.password === password);
  if (!admin) return res.status(401).json({ error: "Invalid login details" });
  req.session.admin = { email: admin.email };
  res.json({ ok: true, email: admin.email });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/admin/me", requireAdmin, (req, res) => {
  res.json({ email: req.session.admin.email });
});

app.get("/api/admin/products", requireAdmin, (req, res) => {
  res.json(loadProducts());
});

app.post("/api/admin/upload", requireAdmin, upload.array("images", 10), (req, res) => {
  const urls = (req.files || []).map(f => "/uploads/" + f.filename);
  res.json({ urls });
});

app.post("/api/admin/products", requireAdmin, (req, res) => {
  const p = req.body;
  const products = loadProducts();
  const product = {
    id: p.id || (p.title || "machine").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-") + "-" + Date.now(),
    title: p.title || "Untitled Machine",
    category: p.category || "Machine",
    description: p.description || "",
    videoUrl: p.videoUrl || "",
    priceMode: p.priceMode === "show" ? "show" : "contact",
    price: p.price || "",
    status: ["published", "draft", "sold"].includes(p.status) ? p.status : "draft",
    images: Array.isArray(p.images) ? p.images : [],
    specs: Array.isArray(p.specs) ? p.specs.filter(s => s && s.key && s.value) : [],
    createdAt: new Date().toISOString()
  };
  products.push(product);
  saveProducts(products);
  res.json(product);
});

app.put("/api/admin/products/:id", requireAdmin, (req, res) => {
  const products = loadProducts();
  const i = products.findIndex(p => p.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: "Product not found" });
  products[i] = { ...products[i], ...req.body, id: req.params.id };
  saveProducts(products);
  res.json(products[i]);
});

app.delete("/api/admin/products/:id", requireAdmin, (req, res) => {
  const products = loadProducts().filter(p => p.id !== req.params.id);
  saveProducts(products);
  res.json({ ok: true });
});

app.get("*", (req, res) => {
  if (req.path.startsWith("/api/")) return res.status(404).end();
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

app.listen(PORT, () => console.log(`Website running at http://localhost:${PORT}`));
